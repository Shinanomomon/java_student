
public interface Interface1 {
          public void show();
}
