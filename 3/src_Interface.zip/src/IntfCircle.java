
public interface IntfCircle{
	public final double PI = 3.14159;

	public double findArea();
	public void showArea();
}
