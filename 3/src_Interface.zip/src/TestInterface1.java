public class TestInterface1 {
	public static void main(String args[]) {
		Interface1 inf = new ImpInf1();

		inf.show();
	}
}
