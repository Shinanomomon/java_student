
public class ImpInf1 implements Interface1 {
	public void show() {
		System.out.println("Overriding method show() in ImpInf1"); 
	}
}
