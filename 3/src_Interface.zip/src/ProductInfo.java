
public interface ProductInfo {

	public static final String MAKER = "My Corp.";
	public static final String PHONE = "02-123-4567";
	
	public double getPrice(int id);
	public void showName();
}
