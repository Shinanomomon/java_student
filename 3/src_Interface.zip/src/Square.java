public class Square implements Shape {
	
	public void draw() {
		System.out.println("Overriding method draw() in Square");
    }

	public void erase() {
		System.out.println("Overriding method erase() in Square");
	}
}
