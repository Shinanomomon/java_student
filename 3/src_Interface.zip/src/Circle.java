
public class Circle implements Shape {

	public void draw() {
		System.out.println("Overriding method draw() in Circle");
	}

	public void erase() {
		System.out.println("Overriding method erase() in Circle");
	}
}
