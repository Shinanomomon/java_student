
public abstract class AbstFood {
	
	public abstract String call ();

	public void show() {
		System.out.println("Clean food, Good taste");
	}
}
