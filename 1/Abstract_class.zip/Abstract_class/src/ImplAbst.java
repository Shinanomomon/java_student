
class ImplAbst extends Abst {
	public void callMe()
	{
		System.out.println("callMe() of ImpleAbst");
	}
}