
class ThePizza extends AbstFood {
	public String call() {
		String str = "The Pizza\n";
		str += "Call 1112";

		return str;
	}
}
