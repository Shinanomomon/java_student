
class KFC extends AbstFood {
	public String call() {
		String str = "KFC\n";
		str += "Call 1150";
	
		return str;
	}
}