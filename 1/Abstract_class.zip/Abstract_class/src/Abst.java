
public abstract class Abst {
	public abstract void callMe();
}

