
class Chester extends AbstFood {
	public String call() {
		String str = "Chester�s Grill\n";
		str += "Call 1145";

		return str;
    }
}
