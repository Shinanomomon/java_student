
class AbstractDemo {
	public static void main(String args[])
	{
		ImplAbst obj = new ImplAbst();
		obj.callMe();
	}
}
